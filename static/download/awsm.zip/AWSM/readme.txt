﻿AWSM - TowerDefence
	by jonapps

besuche uns auf
	jonapps.com
	jonasgerdes.com
	jonathanwiemers.com


Spielprinzip
------------

Der Spieler hat eine Auswahl von Türmen, die er für Energie kaufen und bauen kann. Dies Türme können in einem gewissen Radius mit einer gewissen Frequenz schießen. Mit ihnen muss der Spieler verhindern, dass die Gegner es schaffen, auf ihrem definierten Weg das Ende des Levels zu erreichen. Sollte dies eine gewisse Anzahl an Gegner gelingen, verliert der Spieler und muss/kann das Level erneut spielen. Abgeschossene Gegner verlieren Energie, die der Spieler bekommt und somit neue Türme bauen kann. Die Gegner erscheinen in Wellen, die der Spieler nacheinander auslösen kann. Sind alle Wellen vorüber, hat der Spieler gewonnen.


Steuerung
---------

ÜBERALL
	Escape zum Beenden des Spiels
IM MENÜ
	Pfeiltasten oder W-A-S-D zu Auswahl
	Bestätigen mit ENTER
IM SPIEL
	Pfeiltasten oder W-A-S-D oder Maus an den Rand bewegen: Verschieben der Ansicht
	1, 2, 3, ...: Auswahl eines Turmes
	Klicken: Ausgewählten Turm an Mausposition bauen
	N oder ENTER: Nächste Welle starten (Wenn vorherige vorbei ist)
	Q: Alle Türme abwählen
	M: Zurück ins Hauptmenü
"CHEATS"
	G: Sofortiges Gewinnen des Levels
	L: Sofortiges Verlieren des Levels


Credits
-------

	Idee, Programmierung, Grafik
		Jonas Gerdes
		Jonathan Wiemers
	Logo
		Jonathan Wiemers
	Musik
		Jonas Gerdes
	Icons
		Material Design Icons
		by Google
		https://www.google.com/design/icons/
		CC BY 4.0
	Sounds
		Games and 8-Bit Kit Volume 1 & 2
		by ATOM SPLITTER AUDIO
		Royalty Free

	Bibliotheken
		SFML.NET - http://www.sfml-dev.org/
		FarseerPhysics - https://farseerphysics.codeplex.com/
		Newtonsoft Json.NET - http://www.newtonsoft.com/json
		NAudio - https://naudio.codeplex.com/
		

	